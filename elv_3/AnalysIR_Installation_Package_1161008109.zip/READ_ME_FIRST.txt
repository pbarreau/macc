We have provided quite a lot of documentation in the Information pack.

PLEASE CONSULT THE DOCUMENTATION BEFORE CONTACTING SUPPORT.


You will also find some helpful videos here: https://www.youtube.com/AnalysIR/videos

THANKS!

